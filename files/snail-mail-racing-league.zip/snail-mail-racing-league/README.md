# Snail Mail Racing League — website

A single-page marketing site for the (fictional) Snail Mail Racing League,
where the slowest postcard delivery wins the season.

## Files
- `index.html` — page markup
- `styles.css` — all styling (neo-brutalist postal sticker-book design system)
- `script.js` — live transit counters, standings count-up, hall-of-fame carousel,
  FAQ accordion, form validation, mobile nav, scroll reveals, and injected JSON-LD

## Run locally
Just open `index.html` in any browser — no build step, no dependencies.
For live-reload during editing you can optionally serve it:

    python3 -m http.server 8000
    # then visit http://localhost:8000

(Fonts load from Google Fonts over the network; without a connection it falls
back to system fonts and still works.)

## Deploy
It's a static site — upload the whole folder to any static host:
- Netlify: drag the folder onto the dashboard
- Vercel / Cloudflare Pages / GitHub Pages: point at this folder, no build command

## Notes
- Responsive and mobile-first; keyboard focus styles and reduced-motion are respected.
- All content is placeholder/demo content for a fictional organization.
